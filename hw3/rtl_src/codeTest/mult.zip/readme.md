Unix Running Instructions

1.    Unzip directory using user-preferred method.  Enter man zip for unix method.  Alternatively, see https://unix.stackexchange.com/questions/6596/how-do-i-zip-unzip-on-the-unix-command-line.
2.    Change directory (cd) into directory with source code.  Most likely, cd mult
2.    chmod +x doit
3.    doit mult
